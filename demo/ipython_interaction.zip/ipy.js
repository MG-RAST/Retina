(function () {
    var root = this;
    var ipy = root.ipy = {};

    ipy.read_cell = function (index) {
	return IPython.notebook.get_cell(index).get_text();
    }

    ipy.write_cell = function (index, text) {
	IPython.notebook.get_cell(index).set_text(text);
    }

    ipy.append_to_cell = function (index, text) {
	IPython.notebook.get_cell(index).set_text(IPython.notebook.get_cell(index).get_text() + text);
    }

    ipy.createHTML = function () {
	var cells = document.getElementsByClassName('output_subarea');
	var win = window.open('', "Notebook Output");
	win.document.open();
	win.document.write('<script src="jquery.min.js"></script><script src="http://raw.github.com/MG-RAST/Retina/master/stm.js"></script><script src="http://raw.github.com/MG-RAST/Retina/master/retina.js"></script><script src="http://raw.github.com/MG-RAST/Retina/master/bootstrap.min.js"></script><link rel="stylesheet" type="text/css" href="http://raw.github.com/MG-RAST/Retina/master/bootstrap.min.css">');
	for (i=0;i<cells.length;i++) {
	    win.document.write(cells[i].innerHTML);
	}
	win.document.close();
    }

    ipy.add_cell = function (index, type) {
	if (type == undefined) {
	    type = 'code';
	}
	IPython.notebook.insert_cell_below(type, index);
    }
    
}).call(this);